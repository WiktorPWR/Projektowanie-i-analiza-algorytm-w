#include <iostream>

int main(int argc, char* argv[])
{
    std::cout<< "Tu wykonujemy testy efektywności algorytmów"<<std::endl;
    return 0;
}

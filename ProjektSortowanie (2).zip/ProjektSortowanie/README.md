###### Budowanie projektu:

mkdir build

cd build

cmake ..

make
